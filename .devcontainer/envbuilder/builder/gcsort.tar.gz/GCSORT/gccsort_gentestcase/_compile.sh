make clean
make
mkdir -p bin
cp gcsort_gentestcase bin
