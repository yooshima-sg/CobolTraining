##
##
../bin/gcsort SORT FIELDS=\(8,5,CH,A,13,3,BI,D,16,4,FI,A,20,8,FL,D,28,4,PD,A,32,7,ZD,D\) USE  ../files/sqbig01.dat   RECORD F,90 ORG SQ GIVE ../files/sqbig01_out.dat  RECORD F,90 ORG SQ

