GnuCOBOL with OSS Consortium patch
============

[GnuCOBOL with OSS Consortium patch](https://github.com/opensourcecobol/gnucobol-osscons-patch)は
はOSSコンソーシアムによってｍGnuCOBOLに日本語機能等の機能拡張を行っています。

概要
============

OSSコンソーシアムではopensource COBOLを通して、日本国内でOSSのCOBOLの普及に努めてきました。
今回、日本国内でのGnuCOBOLに対するニーズの高まりを受け、opensoure COBOLで行っていたような日本語機能や
国内のプロジェクトにて開発した成果を本リポジトリにて公開していきます。

完全なGnuCOBOLのフォークではなく、基本的にはパッチ拡張の公開となっていきます。
このため、本家GnuCOBOLのバージョンアップには都度対応していく予定です。

GnuCOBOLのREADME
============

詳細なGnuCOBOLの内容については、オリジナルの[README.md](./README.gnu.md)、[README](./README)を参照してください。

