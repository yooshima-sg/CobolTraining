GnuCOBOL with OSS Consortium patch
============

[GnuCOBOL with OSS Consortium patch](https://github.com/opensourcecobol/gnucobol-osscons-patch)
 is an extension of GnuCOBOL by the OSS consortium.

[日本語のREADMEはこちら](./README_JP.md)

Overview
============

This repository is an extension of GnuCOBOL by the OSS consortium.

We are a Japanese community who works on technical development of opensource COBOL as  OSS Consortium in Japan.
Currently, the number of users who wants to use GnuCOBOL is increasing in Japan and our community develops the GnuCOBOL patches for them.
We would like to add few Japanese-related functions (usage National etc) in future, which we have already developed in the opensource COBOL.

Original GnuCOBOL README
============

See the original [README.md](./README.gnu.md), [README](./README) for more information on GnuCOBOL.
